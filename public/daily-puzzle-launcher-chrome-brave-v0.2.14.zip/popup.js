(() => {
  "use strict";

  const core = globalThis.DailyPuzzlesCore;
  const data = globalThis.DailyPuzzlesStorage;
  const root = document.getElementById("app");
  const dialog = document.getElementById("dialog");
  const dialogForm = document.getElementById("dialog-form");
  let store;
  let view = "today";
  let dragState = null;
  let deferredStore = null;
  let toastTimer;
  let localWrites = 0;
  let scrollSaveTimer;
  let tabState = { anyPuzzleOpen:false, currentGameId:null, games:{} };
  let importText = "";
  let importMode = "new";
  let importSource = "";

  const escapeHtml = (value) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
  const playlist = () => core.activePlaylist(store);
  const games = () => playlist().games;
  const statuses = () => core.getStatuses(store);
  const status = (id) => statuses()[id] || "pending";
  const checkIcon = () => `<svg class="mark-icon check-mark" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2.75 8L6.5 11.75L13.25 4.25"></path></svg>`;
  const skipIcon = () => `<svg class="mark-icon skip-mark" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="8" r="6"></circle><path d="M3.75 12.25L12.25 3.75"></path></svg>`;
  const statusMarkup = (value) => value === "done" ? checkIcon() : value === "skipped" ? skipIcon() : "○";

  function tabLabel(gameId) {
    const value = tabState.games?.[gameId];
    if (value?.current) return "Current";
    if (value?.openCount > 0) return "Open";
    return "";
  }

  function trailingMarkup(game, value) {
    const label = tabLabel(game.id);
    const indicator = label ? `<span class="tab-note">${label}</span>` : "";
    const undo = value === "pending" ? "" : `<button class="undo" data-reset="${escapeHtml(game.id)}">Undo</button>`;
    return `${indicator}${undo}`;
  }

  const STATIC_HOSTS = new Set(["betweenle.com", "wordgy.com", "bonedle.rito.lol", "loldle.net", "pokedle.net", "smashdle.net", "bandle.app", "www.minutecryptic.com", "contexto.me", "conexo.ws", "letroso.com", "expresso.ac"]);

  function hasStaticOverlay(rawUrl) {
    const url = new URL(rawUrl);
    if (STATIC_HOSTS.has(url.hostname)) return true;
    return url.hostname === "www.nytimes.com" && (url.pathname.startsWith("/games/") || url.pathname.startsWith("/crosswords/game/mini") || url.pathname.startsWith("/puzzles/letter-boxed") || url.pathname.startsWith("/puzzles/spelling-bee"));
  }

  function originPattern(rawUrl) {
    const url = new URL(rawUrl);
    return `${url.protocol}//${url.hostname}/*`;
  }

  function scriptId(pattern) {
    let hash = 2166136261;
    for (const character of pattern) { hash ^= character.charCodeAt(0); hash = Math.imul(hash, 16777619); }
    return `custom-site-${(hash >>> 0).toString(36)}`;
  }

  async function ensureOverlayAccess(candidateGames) {
    const origins = [...new Set(candidateGames.filter((game) => !hasStaticOverlay(game.url)).map((game) => originPattern(game.url)))];
    if (!origins.length) return;
    const granted = await chrome.permissions.request({ origins });
    if (!granted) throw new Error("Site access was not granted, so the puzzle was not added.");
    const registered = await chrome.scripting.getRegisteredContentScripts();
    const existingIds = new Set(registered.map((script) => script.id));
    const additions = origins.filter((origin) => !existingIds.has(scriptId(origin))).map((origin) => ({
      id:scriptId(origin), matches:[origin], js:["core.js", "storage.js", "content.js"], runAt:"document_end", persistAcrossSessions:true
    }));
    if (additions.length) await chrome.scripting.registerContentScripts(additions);
  }

  async function addPuzzle(nameInput, urlInput) {
    const name = String(nameInput || "").trim().slice(0, 60);
    const url = core.normalizeWebUrlInput(urlInput);
    if (!name) throw new Error("Enter a puzzle name.");
    if (!url) throw new Error("Enter a website such as example.com/puzzle.");
    await ensureOverlayAccess([{ name, url }]);
    await patch((next) => {
      const list = core.activePlaylist(next).games;
      list.push({ id:core.uniqueGameId(name, list.map((game) => game.id)), name, url, enabled:true });
    });
    return { name, url };
  }

  function toast(message, error = false) {
    clearTimeout(toastTimer);
    let element = document.querySelector(".toast");
    if (!element) {
      element = document.createElement("div");
      element.className = "toast";
      document.body.append(element);
    }
    element.textContent = message;
    element.classList.toggle("error", error);
    requestAnimationFrame(() => element.classList.add("show"));
    toastTimer = setTimeout(() => element.classList.remove("show"), 2400);
  }

  async function persistStore() {
    localWrites += 1;
    try { store = await data.write(store); }
    finally { localWrites -= 1; }
    return store;
  }

  async function patch(mutator, preserveScroll = true) {
    const next = JSON.parse(JSON.stringify(store));
    mutator(next);
    store = core.normalizeStore(next);
    render(preserveScroll);
    await persistStore();
    return store;
  }

  async function navigate(game) {
    if (!game) return;
    rememberPopupScroll();
    store.lastOpenedGameId = game.id;
    await persistStore();
    const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
    const result = await chrome.runtime.sendMessage({ type:"open-game", gameId:game.id, sourceTabId:tab?.id ?? null });
    if (result?.action === "error") { toast(result.message || "The puzzle could not be opened", true); return; }
    window.close();
  }

  async function readTabState() {
    const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
    const result = await chrome.runtime.sendMessage({ type:"get-tab-state", sourceTabId:tab?.id ?? null });
    if (result?.action !== "error") tabState = result || tabState;
    return tabState;
  }

  function topbar() {
    const progress = core.deriveProgress(store);
    return `<header class="topbar">
      <div class="logo" aria-hidden="true">${checkIcon()}</div>
      <div class="top-copy"><h1 class="title">Daily Puzzles</h1><div class="subtitle">${escapeHtml(playlist().name)}${progress.skipped ? ` · ${progress.skipped} skipped` : ""}</div></div>
      <div class="progress-chip">${progress.completed} / ${progress.total}</div>
    </header>
    <nav class="tabs" aria-label="Dashboard sections">
      <button class="tab ${view === "today" ? "active" : ""}" data-view="today">Today</button>
      <button class="tab ${view === "playlists" ? "active" : ""}" data-view="playlists">Playlists</button>
    </nav>`;
  }

  function todayRows() {
    return games().filter((game) => game.enabled !== false).map((game) => {
      const value = status(game.id);
      const currentClass = tabLabel(game.id) === "Current" ? "current" : "";
      return `<div class="today-row ${value} ${currentClass}" data-open-row="${escapeHtml(game.id)}" role="button" tabindex="0" aria-label="Open ${escapeHtml(game.name)}">
        <button class="status" data-cycle="${escapeHtml(game.id)}" aria-label="Change ${escapeHtml(game.name)} status. Currently ${value}." title="Done → Skipped → Pending">${statusMarkup(value)}</button>
        <span class="game-link">${escapeHtml(game.name)}</span><span class="row-trailing">${trailingMarkup(game, value)}</span>
      </div>`;
    }).join("");
  }

  function todayView() {
    const progress = core.deriveProgress(store);
    const percent = progress.total ? Math.min(100, progress.completed / progress.total * 100) : 100;
    const footerGame = core.nextPendingGame(store);
    return `${topbar()}<main class="view">
      <section class="hero">
        <div class="ring" style="--angle:${percent * 3.6}deg"><span>${progress.completed}/${progress.total}</span></div>
        <div><strong>${progress.pending ? `${progress.pending} puzzle${progress.pending === 1 ? "" : "s"} remaining` : "Today's queue is finished"}</strong><p>${progress.skipped ? `${progress.skipped} skipped for today` : "Everything is saved automatically"}</p></div>
      </section>
      <div class="today-list">${todayRows() || `<div class="empty">Enable a puzzle in Playlists to begin.</div>`}</div>
    </main>
    <footer class="footer single">
      <button class="button primary" data-open="${escapeHtml(footerGame?.id || "")}" ${footerGame ? "" : "disabled"}>${progress.pending ? `${core.queueActionVerb(progress, tabState.anyPuzzleOpen)} · ${escapeHtml(footerGame?.name || "")}` : "Finished for today"}</button>
    </footer>`;
  }

  function refreshTodayStatus(gameId) {
    if (view !== "today") return;
    const progress = core.deriveProgress(store);
    const percent = progress.total ? Math.min(100, progress.completed / progress.total * 100) : 100;
    const game = games().find((item) => item.id === gameId);
    const value = status(gameId);
    const row = [...root.querySelectorAll("[data-open-row]")].find((item) => item.dataset.openRow === gameId);
    if (row && game) {
      row.classList.remove("pending", "done", "skipped");
      row.classList.add(value);
      const circle = row.querySelector("[data-cycle]");
      circle.innerHTML = statusMarkup(value);
      circle.setAttribute("aria-label", `Change ${game.name} status. Currently ${value}.`);
      const trailing = row.querySelector(".row-trailing");
      trailing.innerHTML = trailingMarkup(game, value);
    }
    const subtitle = root.querySelector(".subtitle");
    if (subtitle) subtitle.textContent = `${playlist().name}${progress.skipped ? ` · ${progress.skipped} skipped` : ""}`;
    const chip = root.querySelector(".progress-chip");
    if (chip) chip.textContent = `${progress.completed} / ${progress.total}`;
    const ring = root.querySelector(".ring");
    if (ring) {
      ring.style.setProperty("--angle", `${percent * 3.6}deg`);
      const valueNode = ring.querySelector("span");
      if (valueNode) valueNode.textContent = `${progress.completed}/${progress.total}`;
    }
    const heroStrong = root.querySelector(".hero strong");
    if (heroStrong) heroStrong.textContent = progress.pending ? `${progress.pending} puzzle${progress.pending === 1 ? "" : "s"} remaining` : "Today's queue is finished";
    const heroCopy = root.querySelector(".hero p");
    if (heroCopy) heroCopy.textContent = progress.skipped ? `${progress.skipped} skipped for today` : "Everything is saved automatically";
    const footer = root.querySelector(".footer [data-open]");
    const next = core.nextPendingGame(store);
    if (footer) {
      footer.disabled = !next;
      footer.dataset.open = next?.id || "";
      footer.textContent = progress.pending ? `${core.queueActionVerb(progress, tabState.anyPuzzleOpen)} · ${next?.name || ""}` : "Finished for today";
    }
  }

  function refreshTodayTabIndicators() {
    if (view !== "today") return;
    for (const row of root.querySelectorAll("[data-open-row]")) {
      const game = games().find((item) => item.id === row.dataset.openRow);
      if (!game) continue;
      row.classList.toggle("current", tabLabel(game.id) === "Current");
      const trailing = row.querySelector(".row-trailing");
      if (trailing) trailing.innerHTML = trailingMarkup(game, status(game.id));
    }
    const progress = core.deriveProgress(store);
    const next = core.nextPendingGame(store);
    const footer = root.querySelector(".footer [data-open]");
    if (footer) footer.textContent = next ? `${core.queueActionVerb(progress, tabState.anyPuzzleOpen)} · ${next.name}` : "Finished for today";
  }

  function options() {
    return store.playlists.map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === store.activePlaylistId ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("");
  }

  function editRows() {
    return games().map((game) => `<div class="edit-row" data-game-id="${escapeHtml(game.id)}">
      <button class="drag-handle" data-drag-id="${escapeHtml(game.id)}" aria-label="Reorder ${escapeHtml(game.name)}. Use drag, or Arrow Up and Arrow Down." title="Drag to reorder">⠿</button>
      <input class="toggle" type="checkbox" data-toggle="${escapeHtml(game.id)}" aria-label="Enable ${escapeHtml(game.name)}" ${game.enabled !== false ? "checked" : ""}>
      <div class="edit-copy"><span class="edit-name">${escapeHtml(game.name)}</span><span class="edit-url">${escapeHtml(game.url)}</span></div>
      <button class="remove" data-remove="${escapeHtml(game.id)}" aria-label="Remove ${escapeHtml(game.name)}" title="Remove">×</button>
    </div>`).join("");
  }

  function importInspection() {
    return core.inspectPlaylistImport(importText);
  }

  function importSummary(inspection = importInspection()) {
    if (!importText.trim()) return "Paste JSON here or load it from a file.";
    if (!inspection.valid) return `${importSource ? `${importSource}: ` : ""}${inspection.error}`;
    return `${importSource ? `${importSource} · ` : ""}${inspection.name} · ${inspection.count} puzzle${inspection.count === 1 ? "" : "s"}`;
  }

  function transferPanel() {
    const inspection = importInspection();
    const hasText = Boolean(importText.trim());
    return `<details class="section transfer-panel"><summary>Import or export playlist</summary><div class="transfer">
      <section class="transfer-group" aria-labelledby="export-title"><div class="transfer-head"><h3 id="export-title">Export</h3><span>Active playlist</span></div><div class="tools transfer-actions"><button class="tool" data-transfer="export">Export file</button><button class="tool" data-transfer="copy">Copy JSON</button></div></section>
      <section class="transfer-group" aria-labelledby="import-source-title"><div class="transfer-head"><h3 id="import-source-title">Import source</h3><span>Review before importing</span></div><div class="tools transfer-actions"><button class="tool" data-transfer="file">Import JSON file</button></div><input class="visually-hidden" id="import-file" type="file" accept=".json,application/json" tabindex="-1" aria-hidden="true"></section>
      <section class="import-editor" aria-labelledby="import-editor-title"><div class="transfer-head"><h3 id="import-editor-title">Review JSON</h3><span>Editable</span></div><textarea class="textarea" id="transfer" spellcheck="false" placeholder="Or paste playlist JSON here">${escapeHtml(importText)}</textarea><p class="import-summary ${hasText && !inspection.valid ? "error" : ""}" id="import-summary" role="status">${escapeHtml(importSummary(inspection))}</p>
        <div class="import-controls" id="import-controls"><fieldset class="mode-fieldset"><legend>Import mode</legend><div class="mode-selector"><label><input type="radio" name="import-mode" value="new" ${importMode === "new" ? "checked" : ""}><span>Create new playlist</span></label><label><input type="radio" name="import-mode" value="merge" ${importMode === "merge" ? "checked" : ""}><span>Merge into current</span></label></div></fieldset><div class="import-actions"><button class="tool quiet" data-transfer="clear" ${hasText ? "" : "disabled"}>Clear</button><button class="button primary import-primary" data-transfer="import" ${inspection.valid ? "" : "disabled"}>Import playlist</button></div></div>
      </section>
    </div></details>`;
  }

  function playlistsView() {
    return `${topbar()}<main class="view">
      <section class="section">
        <div class="section-head"><h2 class="section-title">Active playlist</h2><span class="count">${games().length} puzzles</span></div>
        <select class="select" id="playlist-select">${options()}</select>
        <div class="tools"><button class="tool" data-playlist="new">New</button><button class="tool" data-playlist="duplicate">Duplicate</button><button class="tool" data-playlist="rename">Rename</button><button class="tool danger" data-playlist="delete">Delete</button></div>
      </section>
      <section class="section">
        <div class="section-head"><h2 class="section-title">Add a puzzle</h2></div>
        <form class="add-form" id="add-form"><input class="field" id="new-name" required maxlength="60" placeholder="Puzzle name"><button class="tool" type="submit">Add</button><input class="field url" id="new-url" required type="text" inputmode="url" autocomplete="url" spellcheck="false" placeholder="example.com/puzzle"></form>
      </section>
      <section class="section">
        <div class="section-head"><h2 class="section-title">Drag to reorder</h2><span class="count">Saved on drop</span></div>
        <div class="edit-list" id="edit-list">${editRows() || `<div class="empty">This playlist is empty.</div>`}</div>
      </section>
      ${transferPanel()}
    </main><footer class="footer" hidden></footer>`;
  }

  function render(preserveScroll = false) {
    if (!store || dragState) return;
    const currentScrollTop = root.querySelector(".view")?.scrollTop;
    const scrollTop = core.resolveScrollPosition(store.ui?.popupScroll?.[view], currentScrollTop, preserveScroll);
    const transferOpen = preserveScroll && root.querySelector("details")?.open;
    root.innerHTML = `<div class="app">${view === "today" ? todayView() : playlistsView()}</div>`;
    const nextView = root.querySelector(".view");
    if (nextView) nextView.scrollTop = scrollTop;
    if (transferOpen) root.querySelector("details")?.setAttribute("open", "");
  }

  function rememberPopupScroll() {
    const activeView = root.querySelector(".view");
    if (!activeView) return false;
    const scrollTop = Math.max(0, Math.round(activeView.scrollTop));
    store.ui.popupScroll ||= { today:0, playlists:0 };
    if (store.ui.popupScroll[view] === scrollTop) return false;
    store.ui.popupScroll[view] = scrollTop;
    return true;
  }

  function ask({ title, copy, label, value = "", confirm = "Save", input = true, danger = false, cancel = true }) {
    document.getElementById("dialog-title").textContent = title;
    document.getElementById("dialog-copy").textContent = copy || "";
    document.getElementById("dialog-label").textContent = label || "";
    document.getElementById("dialog-label-wrap").hidden = !input;
    const field = document.getElementById("dialog-input");
    field.value = value;
    const confirmButton = document.getElementById("dialog-confirm");
    confirmButton.textContent = confirm;
    confirmButton.classList.toggle("danger", danger);
    const cancelButton = dialogForm.querySelector('[value="cancel"]');
    cancelButton.hidden = !cancel;
    dialogForm.querySelector(".dialog-actions").classList.toggle("single", !cancel);
    dialog.returnValue = "cancel";
    dialog.showModal();
    if (input) { field.focus(); field.select(); } else confirmButton.focus();
    return new Promise((resolve) => {
      dialog.addEventListener("close", () => resolve(dialog.returnValue === "default" ? (input ? field.value.trim() : true) : null), { once:true });
    });
  }

  async function playlistAction(action) {
    const current = playlist();
    if (action === "new") {
      const name = await ask({ title:"New playlist", copy:"Start with a clean queue.", label:"Playlist name", value:"My puzzles", confirm:"Create" });
      if (!name) return;
      await patch((next) => { const id = core.uniqueGameId(name, next.playlists.map((item) => item.id)); next.playlists.push({ id, name, games:[] }); next.activePlaylistId = id; });
    }
    if (action === "duplicate") {
      const name = await ask({ title:"Duplicate playlist", copy:`Create a copy of ${current.name}.`, label:"Copy name", value:`${current.name} copy`, confirm:"Duplicate" });
      if (!name) return;
      await patch((next) => { const id = core.uniqueGameId(name, next.playlists.map((item) => item.id)); next.playlists.push({ id, name, games:JSON.parse(JSON.stringify(current.games)) }); next.activePlaylistId = id; });
    }
    if (action === "rename") {
      const name = await ask({ title:"Rename playlist", copy:"Choose a short name you will recognize.", label:"Playlist name", value:current.name });
      if (!name) return;
      await patch((next) => { core.activePlaylist(next).name = name; });
    }
    if (action === "delete" && store.playlists.length === 1) {
      await ask({ title:"Keep one playlist", copy:"Daily Puzzle Launcher needs at least one playlist. Create or duplicate another playlist before deleting this one.", input:false, confirm:"Got it", cancel:false });
      return;
    }
    if (action === "delete") {
      const confirmed = await ask({ title:`Delete “${current.name}”?`, copy:"The playlist will be removed. Today's puzzle history is preserved.", input:false, confirm:"Delete", danger:true });
      if (!confirmed) return;
      await patch((next) => { next.playlists = next.playlists.filter((item) => item.id !== current.id); next.activePlaylistId = next.playlists[0].id; });
    }
  }

  function downloadPlaylist(text) {
    const blob = new Blob([text], { type:"application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${core.slugify(playlist().name)}-daily-puzzles.json`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  function updateImportEditor({ focus = false, preserveScrollTop = null } = {}) {
    const textarea = document.getElementById("transfer");
    if (!textarea) return;
    const viewNode = root.querySelector(".view");
    const scrollTop = Number.isFinite(preserveScrollTop) ? preserveScrollTop : viewNode?.scrollTop;
    if (window.scrollX || window.scrollY) window.scrollTo(0, 0);
    if (textarea.value !== importText) textarea.value = importText;
    const inspection = importInspection();
    const hasText = Boolean(importText.trim());
    const summary = document.getElementById("import-summary");
    if (summary) {
      summary.textContent = importSummary(inspection);
      summary.classList.toggle("error", hasText && !inspection.valid);
    }
    const clearButton = root.querySelector('[data-transfer="clear"]');
    if (clearButton) clearButton.disabled = !hasText;
    const importButton = root.querySelector('[data-transfer="import"]');
    if (importButton) importButton.disabled = !inspection.valid;
    for (const radio of root.querySelectorAll('[name="import-mode"]')) radio.checked = radio.value === importMode;
    if (focus) { textarea.focus(); textarea.setSelectionRange(textarea.value.length, textarea.value.length); }
    if (viewNode && Number.isFinite(scrollTop)) {
      viewNode.scrollTop = scrollTop;
      requestAnimationFrame(() => requestAnimationFrame(() => { if (viewNode.isConnected) viewNode.scrollTop = scrollTop; }));
    }
  }

  async function transfer(action) {
    const textarea = document.getElementById("transfer");
    if (!textarea) return;
    const scrollTop = root.querySelector(".view")?.scrollTop;
    try {
      if (action === "export" || action === "copy") {
        const text = core.exportPlaylist(playlist());
        if (action === "copy") await navigator.clipboard.writeText(text);
        else downloadPlaylist(text);
        toast(action === "copy" ? "Playlist JSON copied" : "Playlist JSON downloaded");
        return;
      }
      if (action === "file") { document.getElementById("import-file")?.click(); return; }
      if (action === "clear") {
        importText = "";
        importSource = "";
        updateImportEditor({ preserveScrollTop:scrollTop });
        return;
      }
      if (action !== "import") return;
      const inspection = importInspection();
      if (!inspection.valid) { toast(inspection.error, true); updateImportEditor(); return; }
      await ensureOverlayAccess(inspection.parsed.games);
      rememberPopupScroll();
      const imported = core.applyPlaylistImport(store, importText, importMode);
      store = imported.store;
      importText = "";
      importSource = "";
      render(true);
      await persistStore();
      toast(imported.mode === "new"
        ? `Created ${imported.name} with ${imported.count} puzzle${imported.count === 1 ? "" : "s"}`
        : `Added ${imported.count} new puzzle${imported.count === 1 ? "" : "s"}`);
    } catch (error) { toast(error?.message || "The playlist could not be imported", true); }
  }

  function startDrag(handle, event) {
    if (event.button !== 0 || dragState) return;
    const row = handle.closest(".edit-row");
    const list = row.parentElement;
    const rect = row.getBoundingClientRect();
    const placeholder = document.createElement("div");
    placeholder.className = "drop-placeholder";
    placeholder.style.height = `${rect.height}px`;
    const originalIndex = [...list.children].indexOf(row);
    list.replaceChild(placeholder, row);
    document.body.append(row);
    row.classList.add("dragging");
    Object.assign(row.style, { left:`${rect.left}px`, top:`${rect.top}px`, width:`${rect.width}px`, height:`${rect.height}px` });
    list.classList.add("dragging-list");
    handle.setPointerCapture(event.pointerId);
    dragState = {
      pointerId:event.pointerId, row, list, placeholder, handle,
      offsetY:event.clientY - rect.top, originTop:rect.top, height:rect.height,
      latestY:event.clientY, lastCenterY:rect.top + rect.height / 2, direction:0, frame:0, originalIndex
    };
    event.preventDefault();
  }

  function paintDragFrame() {
    if (!dragState) return;
    const { row, list, placeholder, offsetY, originTop, height, latestY } = dragState;
    dragState.frame = 0;
    const dragTop = latestY - offsetY;
    const dragCenterY = dragTop + height / 2;
    const movement = dragCenterY - dragState.lastCenterY;
    if (Math.abs(movement) > 0.5) dragState.direction = Math.sign(movement);
    dragState.lastCenterY = dragCenterY;
    const snapRatio = dragState.direction > 0 ? 0.35 : dragState.direction < 0 ? 0.65 : 0.5;
    row.style.setProperty("--drag-y", `${dragTop - originTop}px`);
    let desiredNext = null;
    for (const candidate of list.querySelectorAll(".edit-row")) {
      const rect = candidate.getBoundingClientRect();
      if (dragCenterY < rect.top + rect.height * snapRatio) { desiredNext = candidate; break; }
    }
    if (placeholder.nextElementSibling === desiredNext || (!desiredNext && placeholder === list.lastElementChild)) return;
    list.insertBefore(placeholder, desiredNext);
  }

  function moveDrag(event) {
    if (!dragState || dragState.pointerId !== event.pointerId) return;
    dragState.latestY = event.clientY;
    if (!dragState.frame) dragState.frame = requestAnimationFrame(paintDragFrame);
    event.preventDefault();
  }

  async function endDrag(event, cancel = false) {
    if (!dragState || dragState.pointerId !== event.pointerId) return;
    if (dragState.frame) cancelAnimationFrame(dragState.frame);
    dragState.latestY = event.clientY;
    if (!cancel) paintDragFrame();
    const { row, list, placeholder, originalIndex } = dragState;
    dragState = null;
    if (cancel) list.insertBefore(placeholder, list.children[originalIndex] || null);
    placeholder.replaceWith(row);
    row.classList.remove("dragging");
    row.removeAttribute("style");
    list.classList.remove("dragging-list");
    const orderedIds = [...list.querySelectorAll(".edit-row")].map((item) => item.dataset.gameId);
    const hadDeferredStore = Boolean(deferredStore);
    const next = JSON.parse(JSON.stringify(deferredStore || store));
    deferredStore = null;
    core.activePlaylist(next).games = core.reorderGames(core.activePlaylist(next).games, orderedIds);
    store = core.normalizeStore(next);
    await persistStore();
    if (hadDeferredStore) render(true);
    requestAnimationFrame(() => root.querySelector(`[data-drag-id="${CSS.escape(row.dataset.gameId)}"]`)?.focus());
  }

  async function keyboardReorder(handle, direction) {
    const id = handle.dataset.dragId;
    const ids = games().map((game) => game.id);
    const index = ids.indexOf(id);
    const destination = index + direction;
    if (index < 0 || destination < 0 || destination >= ids.length) return;
    [ids[index], ids[destination]] = [ids[destination], ids[index]];
    await patch((next) => { core.activePlaylist(next).games = core.reorderGames(core.activePlaylist(next).games, ids); });
    requestAnimationFrame(() => root.querySelector(`[data-drag-id="${CSS.escape(id)}"]`)?.focus());
  }

  root.addEventListener("click", async (event) => {
    const cycle = event.target.closest("[data-cycle]");
    if (cycle) {
      const id = cycle.dataset.cycle;
      store = core.setGameStatus(store, id, core.nextGameStatus(status(id)));
      refreshTodayStatus(id);
      await persistStore();
      return;
    }
    const button = event.target.closest("button");
    if (button?.disabled) return;
    if (button?.dataset.reset) {
      const id = button.dataset.reset;
      store = core.setGameStatus(store, id, "pending");
      refreshTodayStatus(id);
      await persistStore();
      return;
    }
    if (button?.dataset.view) {
      rememberPopupScroll();
      view = button.dataset.view;
      render();
      await persistStore();
      return;
    }
    if (button?.dataset.open) { await navigate(games().find((game) => game.id === button.dataset.open)); return; }
    if (button?.dataset.playlist) { await playlistAction(button.dataset.playlist); return; }
    if (button?.dataset.transfer) { await transfer(button.dataset.transfer); return; }
    if (button?.dataset.remove) {
      const game = games().find((item) => item.id === button.dataset.remove);
      if (!game) return;
      const confirmed = await ask({ title:`Remove “${game.name}”?`, copy:"This removes it from the current playlist only.", input:false, confirm:"Remove", danger:true });
      if (confirmed) await patch((next) => { core.activePlaylist(next).games = core.activePlaylist(next).games.filter((item) => item.id !== game.id); });
      return;
    }
    const row = event.target.closest("[data-open-row]");
    if (row) await navigate(games().find((game) => game.id === row.dataset.openRow));
  });

  root.addEventListener("change", async (event) => {
    if (event.target.id === "new-url") {
      const normalized = core.normalizeWebUrlInput(event.target.value);
      if (normalized) event.target.value = normalized;
      return;
    }
    if (event.target.id === "import-file") {
      const scrollTop = root.querySelector(".view")?.scrollTop;
      const file = event.target.files?.[0] || null;
      const loaded = await core.loadFileImport(file, importText);
      event.target.value = "";
      if (loaded.cancelled) return;
      if (!loaded.ok) { toast(loaded.error, true); return; }
      importText = loaded.text;
      importSource = file?.name ? `File · ${file.name}` : "File";
      updateImportEditor({ preserveScrollTop:scrollTop });
      return;
    }
    if (event.target.name === "import-mode") {
      importMode = event.target.value === "merge" ? "merge" : "new";
      updateImportEditor();
      return;
    }
    if (event.target.id === "playlist-select") await patch((next) => { next.activePlaylistId = event.target.value; });
    if (event.target.dataset.toggle) {
      const game = games().find((item) => item.id === event.target.dataset.toggle);
      if (game) game.enabled = event.target.checked;
      await persistStore();
    }
  });

  root.addEventListener("input", (event) => {
    if (event.target.id !== "transfer") return;
    importText = event.target.value;
    importSource = "Manual input";
    updateImportEditor();
  });

  root.addEventListener("scroll", (event) => {
    if (!event.target.matches?.(".view") || !rememberPopupScroll()) return;
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = setTimeout(() => persistStore().catch((error) => toast(error?.message || "Could not save scroll position", true)), 120);
  }, true);

  root.addEventListener("submit", async (event) => {
    if (event.target.id !== "add-form") return;
    event.preventDefault();
    const name = document.getElementById("new-name").value.trim();
    const url = document.getElementById("new-url").value.trim();
    try {
      const added = await addPuzzle(name, url);
      toast(`${added.name} added`);
    } catch (error) { toast(error?.message || "The puzzle could not be added", true); }
  });

  root.addEventListener("pointerdown", (event) => {
    const handle = event.target.closest("[data-drag-id]");
    if (handle) startDrag(handle, event);
  });
  document.addEventListener("pointermove", moveDrag);
  document.addEventListener("pointerup", (event) => endDrag(event));
  document.addEventListener("pointercancel", (event) => endDrag(event, true));
  root.addEventListener("keydown", (event) => {
    const handle = event.target.closest("[data-drag-id]");
    if (handle && ["ArrowUp", "ArrowDown"].includes(event.key)) {
      event.preventDefault();
      keyboardReorder(handle, event.key === "ArrowUp" ? -1 : 1);
      return;
    }
    const row = event.target.closest("[data-open-row]");
    if (row && event.target === row && ["Enter", " "].includes(event.key)) {
      event.preventDefault();
      navigate(games().find((game) => game.id === row.dataset.openRow));
    }
  });

  dialogForm.addEventListener("submit", () => { dialog.returnValue = document.activeElement?.value === "cancel" ? "cancel" : "default"; });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "tab-state-changed") return false;
    readTabState().then(refreshTodayTabIndicators).catch(() => {});
    return false;
  });
  data.subscribe((next) => {
    if (localWrites) { store = next; return; }
    if (JSON.stringify(next) === JSON.stringify(store)) return;
    if (dragState) deferredStore = next;
    else { store = next; render(true); }
  });
  data.read().then(async (next) => { store = next; await readTabState(); render(); }).catch((error) => { root.innerHTML = `<div class="empty">Could not load Daily Puzzle Launcher.<br>${escapeHtml(error.message)}</div>`; });
})();
