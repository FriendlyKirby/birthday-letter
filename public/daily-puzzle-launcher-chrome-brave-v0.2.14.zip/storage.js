(() => {
  "use strict";

  const STORAGE_KEY = "daily-puzzle-launcher:store";
  const { normalizeStore } = globalThis.DailyPuzzlesCore;

  async function read() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return normalizeStore(result[STORAGE_KEY] || null);
  }

  async function write(store) {
    const normalized = normalizeStore(store);
    await chrome.storage.local.set({ [STORAGE_KEY]: normalized });
    return normalized;
  }

  async function update(mutator) {
    const next = await read();
    const result = mutator(next) || next;
    return write(result);
  }

  function subscribe(listener) {
    const handler = (changes, areaName) => {
      if (areaName !== "local" || !changes[STORAGE_KEY]) return;
      listener(normalizeStore(changes[STORAGE_KEY].newValue));
    };
    chrome.storage.onChanged.addListener(handler);
    return () => chrome.storage.onChanged.removeListener(handler);
  }

  globalThis.DailyPuzzlesStorage = Object.freeze({ STORAGE_KEY, read, write, update, subscribe });
})();
