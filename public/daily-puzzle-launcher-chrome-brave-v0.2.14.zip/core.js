(() => {
  "use strict";
const STORE_VERSION = 1;
const MAX_PLAYLIST_IMPORT_CHARS = 250_000;
const DEFAULT_PLAYLIST_REVISION = 2;

const DEFAULT_GAMES = Object.freeze([
  { id: "wordle", name: "Wordle", url: "https://www.nytimes.com/games/wordle/index.html", enabled: true },
  { id: "connections", name: "Connections", url: "https://www.nytimes.com/games/connections", enabled: true },
  { id: "mini", name: "The Mini", url: "https://www.nytimes.com/crosswords/game/mini", enabled: true },
  { id: "strands", name: "Strands", url: "https://www.nytimes.com/games/strands", enabled: true },
  { id: "letter-boxed", name: "Letter Boxed", url: "https://www.nytimes.com/puzzles/letter-boxed", enabled: true },
  { id: "spelling-bee", name: "Spelling Bee", url: "https://www.nytimes.com/puzzles/spelling-bee", enabled: true },
  { id: "betweenle", name: "Betweenle", url: "https://betweenle.com/", enabled: true },
  { id: "wordgy", name: "Wordgy", url: "https://wordgy.com/", enabled: true },
  { id: "bonedle", name: "Bonedle", url: "https://bonedle.rito.lol/", enabled: true },
  { id: "loldle", name: "LoLdle", url: "https://loldle.net/", enabled: true },
  { id: "pokedle", name: "Pokédle", url: "https://pokedle.net/", enabled: true },
  { id: "smashdle", name: "Smashdle", url: "https://smashdle.net/", enabled: true },
  { id: "bandle", name: "Bandle", url: "https://bandle.app/menu", enabled: true },
  { id: "minute-cryptic", name: "Minute Cryptic", url: "https://www.minutecryptic.com/", enabled: true },
  { id: "contexto", name: "Contexto", url: "https://contexto.me/en/", enabled: true },
  { id: "conexo", name: "Conexo", url: "https://conexo.ws/en/", enabled: true },
  { id: "letroso", name: "Letroso", url: "https://letroso.com/en/", enabled: true },
  { id: "expresso", name: "Expresso", url: "https://expresso.ac/en/", enabled: true }
]);

const clone = (value) => JSON.parse(JSON.stringify(value));

function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function slugify(value) {
  const slug = String(value || "puzzle")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return slug || "puzzle";
}

function uniqueGameId(name, existingIds = []) {
  const used = new Set(existingIds);
  const base = slugify(name);
  if (!used.has(base)) return base;
  let suffix = 2;
  while (used.has(`${base}-${suffix}`)) suffix += 1;
  return `${base}-${suffix}`;
}

function isSupportedGameUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function normalizeWebUrlInput(rawUrl) {
  const value = String(rawUrl || "").trim();
  if (!value) return "";
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(value) && !/^https?:\/\//i.test(value)) return "";
  if (/^(?:about|chrome|chrome-extension|data|file|javascript|mailto|tel):/i.test(value)) return "";
  const candidate = /^https?:\/\//i.test(value) ? value : `https://${value}`;
  try {
    const url = new URL(candidate);
    if (!(["http:", "https:"].includes(url.protocol)) || !url.hostname || url.username || url.password) return "";
    return url.href;
  } catch {
    return "";
  }
}

function createDefaultStore(dateKey = localDateKey()) {
  return {
    version: STORE_VERSION,
    defaultPlaylistRevision: DEFAULT_PLAYLIST_REVISION,
    activePlaylistId: "daily",
    playlists: [{ id: "daily", name: "Daily", games: clone(DEFAULT_GAMES) }],
    dailyRecords: { [dateKey]: { statuses: {} } },
    lastOpenedGameId: "wordle",
    ui: {
      expanded: false,
      overlayExpanded: false,
      view: "today",
      position: null,
      overlayScrollTop: 0,
      popupScroll: { today: 0, playlists: 0 }
    }
  };
}

function normalizeStore(value, dateKey = localDateKey()) {
  const fallback = createDefaultStore(dateKey);
  if (!value || typeof value !== "object" || value.version !== STORE_VERSION) return fallback;
  const playlists = Array.isArray(value.playlists)
    ? value.playlists.filter((playlist) => playlist && typeof playlist.id === "string" && Array.isArray(playlist.games))
    : [];
  if (!playlists.length) return fallback;
  const normalizedPlaylists = clone(playlists);
  if ((Number(value.defaultPlaylistRevision) || 1) < DEFAULT_PLAYLIST_REVISION) {
    const daily = normalizedPlaylists.find((playlist) => playlist.id === "daily");
    if (daily && !daily.games.some((game) => game.id === "spelling-bee")) {
      const after = daily.games.findIndex((game) => game.id === "letter-boxed");
      daily.games.splice(after < 0 ? daily.games.length : after + 1, 0, clone(DEFAULT_GAMES.find((game) => game.id === "spelling-bee")));
    }
  }
  const activePlaylistId = playlists.some((playlist) => playlist.id === value.activePlaylistId)
    ? value.activePlaylistId
    : playlists[0].id;
  return {
    ...fallback,
    ...value,
    defaultPlaylistRevision: DEFAULT_PLAYLIST_REVISION,
    activePlaylistId,
    playlists: normalizedPlaylists,
    dailyRecords: value.dailyRecords && typeof value.dailyRecords === "object" ? clone(value.dailyRecords) : {},
    ui: {
      ...fallback.ui,
      ...(value.ui || {}),
      popupScroll: { ...fallback.ui.popupScroll, ...(value.ui?.popupScroll || {}) }
    }
  };
}

function activePlaylist(store) {
  return store.playlists.find((playlist) => playlist.id === store.activePlaylistId) || store.playlists[0];
}

function getStatuses(store, dateKey = localDateKey()) {
  return store.dailyRecords?.[dateKey]?.statuses || {};
}

function setGameStatus(store, gameId, status, dateKey = localDateKey()) {
  if (!["pending", "done", "skipped"].includes(status)) throw new Error(`Unknown status: ${status}`);
  const next = clone(store);
  next.dailyRecords ||= {};
  next.dailyRecords[dateKey] ||= { statuses: {} };
  if (status === "pending") delete next.dailyRecords[dateKey].statuses[gameId];
  else next.dailyRecords[dateKey].statuses[gameId] = status;
  return next;
}

function nextGameStatus(status) {
  if (status === "pending") return "done";
  if (status === "done") return "skipped";
  return "pending";
}

function deriveProgress(store, dateKey = localDateKey()) {
  const games = activePlaylist(store).games.filter((game) => game.enabled !== false);
  const statuses = getStatuses(store, dateKey);
  const skipped = games.filter((game) => statuses[game.id] === "skipped").length;
  const done = games.filter((game) => statuses[game.id] === "done").length;
  const completed = done + skipped;
  const total = games.length;
  const pending = total - completed;
  return { completed, done, total, skipped, pending, enabled: games.length };
}

function nextPendingGame(store, afterGameId = null, dateKey = localDateKey()) {
  const games = activePlaylist(store).games.filter((game) => game.enabled !== false);
  if (!games.length) return null;
  const statuses = getStatuses(store, dateKey);
  const startIndex = Math.max(-1, games.findIndex((game) => game.id === afterGameId));
  for (let offset = 1; offset <= games.length; offset += 1) {
    const game = games[(startIndex + offset) % games.length];
    if (!statuses[game.id]) return game;
  }
  return null;
}

function queueActionVerb(progress, anyPuzzleOpen = false) {
  return progress?.completed > 0 || anyPuzzleOpen ? "Continue" : "Start";
}

function resolveScrollPosition(savedPosition, currentPosition, preserveCurrent = false) {
  if (preserveCurrent && Number.isFinite(currentPosition)) return Math.max(0, currentPosition);
  const saved = Number(savedPosition);
  return Number.isFinite(saved) ? Math.max(0, saved) : 0;
}

function reorderGames(games, orderedIds) {
  if (!Array.isArray(games) || !Array.isArray(orderedIds)) throw new Error("Games and order must be arrays.");
  const byId = new Map(games.map((game) => [game.id, game]));
  const seen = new Set();
  const reordered = [];
  for (const id of orderedIds) {
    if (seen.has(id) || !byId.has(id)) continue;
    reordered.push(byId.get(id));
    seen.add(id);
  }
  for (const game of games) {
    if (!seen.has(game.id)) reordered.push(game);
  }
  return reordered;
}

function comparableUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    let path = url.pathname.replace(/\/index\.html?$/i, "/").replace(/\/+$/, "");
    return { host, path: path || "/" };
  } catch {
    return null;
  }
}

function findGameForUrl(games, rawUrl) {
  const current = comparableUrl(rawUrl);
  if (!current) return null;
  const matches = games
    .map((game) => ({ game, comparable: comparableUrl(game.url) }))
    .filter(({ comparable }) => comparable && comparable.host === current.host)
    .filter(({ comparable }) => comparable.path === "/" || current.path === comparable.path || current.path.startsWith(`${comparable.path}/`))
    .sort((a, b) => b.comparable.path.length - a.comparable.path.length);
  return matches[0]?.game || null;
}

function findOpenGameTab(games, tabs, gameId) {
  const target = games.find((game) => game.id === gameId);
  if (!target || !Array.isArray(tabs)) return null;
  const targetUrl = comparableUrl(target.url);
  if (!targetUrl) return null;
  const gamesOnHost = games.filter((game) => comparableUrl(game.url)?.host === targetUrl.host);
  return tabs.find((tab) => {
    if (!tab?.id || typeof tab.url !== "string") return false;
    if (findGameForUrl(games, tab.url)?.id === target.id) return true;
    return gamesOnHost.length === 1 && comparableUrl(tab.url)?.host === targetUrl.host;
  }) || null;
}

function exportPlaylist(playlist) {
  return JSON.stringify({
    format: "daily-puzzle-playlist",
    version: 1,
    name: playlist.name,
    games: playlist.games.map(({ name, url, enabled = true }) => ({ name, url, enabled }))
  }, null, 2);
}

function parsePlaylist(text) {
  if (typeof text !== "string" || !text.trim()) throw new Error("Paste or load playlist JSON first.");
  if (text.length > MAX_PLAYLIST_IMPORT_CHARS) throw new Error("Playlist JSON is too large.");
  let value;
  try {
    value = JSON.parse(text);
  } catch {
    throw new Error("That is not valid JSON.");
  }
  if (value?.format !== "daily-puzzle-playlist" || value?.version !== 1 || !Array.isArray(value.games)) {
    throw new Error("That is not a Daily Puzzle Launcher playlist.");
  }
  if (!value.games.length) throw new Error("The playlist is empty.");
  const games = value.games.map((game, index) => {
    if (!game || typeof game.name !== "string" || typeof game.url !== "string") {
      throw new Error(`Puzzle ${index + 1} is missing a name or URL.`);
    }
    if (!isSupportedGameUrl(game.url)) throw new Error(`Puzzle ${index + 1} must use an http or https URL.`);
    const name = game.name.trim();
    if (!name) throw new Error(`Puzzle ${index + 1} is missing a name or URL.`);
    return { name:name.slice(0, 80), url:game.url, enabled:game.enabled !== false };
  });
  return { name:String(value.name || "Imported playlist").trim().slice(0, 80) || "Imported playlist", games };
}

function inspectPlaylistImport(text) {
  try {
    const parsed = parsePlaylist(text);
    return { valid:true, parsed, name:parsed.name, count:parsed.games.length, error:"" };
  } catch (error) {
    return { valid:false, parsed:null, name:"", count:0, error:error?.message || "The playlist could not be read." };
  }
}

async function loadFileImport(file, existingText = "") {
  if (!file) return { ok:false, cancelled:true, text:existingText, error:"" };
  if (Number(file.size) > MAX_PLAYLIST_IMPORT_CHARS) return { ok:false, cancelled:false, text:existingText, error:"That file is too large." };
  try {
    const text = await file.text();
    if (typeof text !== "string" || !text.trim()) return { ok:false, cancelled:false, text:existingText, error:"That file is empty." };
    if (text.length > MAX_PLAYLIST_IMPORT_CHARS) return { ok:false, cancelled:false, text:existingText, error:"That file is too large." };
    return { ok:true, cancelled:false, text, error:"" };
  } catch {
    return { ok:false, cancelled:false, text:existingText, error:"That file could not be read." };
  }
}

function applyPlaylistImport(store, text, mode = "new") {
  const parsed = parsePlaylist(text);
  const next = normalizeStore(clone(store));
  const imported = [];
  for (const game of parsed.games) {
    imported.push({ ...game, id:uniqueGameId(game.name, imported.map((item) => item.id)) });
  }
  if (mode === "new") {
    const id = uniqueGameId(parsed.name, next.playlists.map((item) => item.id));
    next.playlists.push({ id, name:parsed.name, games:imported });
    next.activePlaylistId = id;
    return { store:normalizeStore(next), count:imported.length, name:parsed.name, mode };
  }
  if (mode !== "merge") throw new Error("Choose a valid import mode.");
  const current = activePlaylist(next);
  const before = current.games.length;
  current.games = mergeGames(current.games, imported);
  return { store:normalizeStore(next), count:current.games.length - before, name:current.name, mode };
}

function mergeGames(existingGames, incomingGames) {
  const next = clone(existingGames);
  const seen = new Set(existingGames.map((game) => {
    const url = comparableUrl(game.url);
    return url ? `${url.host}${url.path}` : game.url;
  }));
  for (const incoming of incomingGames) {
    const url = comparableUrl(incoming.url);
    const key = url ? `${url.host}${url.path}` : incoming.url;
    if (seen.has(key)) continue;
    next.push({ ...clone(incoming), id: uniqueGameId(incoming.name, next.map((game) => game.id)) });
    seen.add(key);
  }
  return next;
}


  globalThis.DailyPuzzlesCore = Object.freeze({ STORE_VERSION, MAX_PLAYLIST_IMPORT_CHARS, DEFAULT_GAMES, localDateKey, slugify, uniqueGameId, isSupportedGameUrl, normalizeWebUrlInput, createDefaultStore, normalizeStore, activePlaylist, getStatuses, setGameStatus, nextGameStatus, deriveProgress, nextPendingGame, queueActionVerb, resolveScrollPosition, reorderGames, findGameForUrl, findOpenGameTab, exportPlaylist, parsePlaylist, inspectPlaylistImport, loadFileImport, applyPlaylistImport, mergeGames });
})();
