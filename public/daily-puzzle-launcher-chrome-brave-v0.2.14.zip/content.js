(() => {
  "use strict";

  const core = globalThis.DailyPuzzlesCore;
  const data = globalThis.DailyPuzzlesStorage;
  const ROOT_ID = "daily-puzzle-launcher-extension";
  let store;
  let saving = false;
  let hasRendered = false;
  let localWrites = 0;
  let scrollSaveTimer;
  let tabState = { anyPuzzleOpen:false, currentGameId:null, games:{} };
  let duplicateGameId = null;

  document.getElementById(ROOT_ID)?.remove();
  const host = document.createElement("div");
  host.id = ROOT_ID;
  host.style.cssText = "all:initial!important;position:fixed!important;right:18px!important;bottom:18px!important;z-index:2147483647!important";
  document.documentElement.append(host);
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      :host { color-scheme: light dark; }
      *, *::before, *::after { box-sizing: border-box; }
      button { font: inherit; cursor: pointer; }
      .shell {
        --ink:#171922; --muted:#696b78; --surface:#fffefa; --surface-2:#f4f1ea; --line:#dedbd2;
        --accent:#5b49d6; --accent-2:#4735bc; --done:#19805c; --skip:#aa651a;
        width:min(365px,calc(100vw - 20px)); overflow:hidden; border:1px solid color-mix(in srgb,var(--line) 82%,transparent);
        border-radius:18px; color:var(--ink); background:var(--surface);
        box-shadow:0 5px 16px rgba(16,18,28,.14);
        font:15px/1.4 "Segoe UI Variable Text","Segoe UI",ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,sans-serif;
        -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility;
        animation:dp-in .22s cubic-bezier(.2,.8,.2,1);
      }
      @keyframes dp-in { from { opacity:0; transform:translateY(8px) scale(.98) } }
      .compact { display:grid; grid-template-columns:auto minmax(0,1fr) auto; align-items:center; gap:9px; padding:9px; }
      .grip { width:27px; height:39px; border:0; border-radius:9px; color:var(--muted); background:transparent; touch-action:none; cursor:grab; }
      .grip:active { cursor:grabbing; }
      .grip:hover { color:var(--ink); background:var(--surface-2); }
      .copy { min-width:0; }
      .kicker { color:var(--muted); font-size:11px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; }
      .title { overflow:hidden; margin-top:1px; font-weight:700; text-overflow:ellipsis; white-space:nowrap; }
      .actions { display:flex; align-items:center; gap:6px; }
      .icon { display:grid; width:38px; height:38px; place-items:center; border:1px solid var(--line); border-radius:11px; color:var(--ink); background:transparent; }
      .icon:hover { background:var(--surface-2); transform:translateY(-1px); }
      .icon.skip-action { width:40px; min-width:40px; height:40px; padding:0; color:var(--muted); font-weight:700; }
      .icon.primary { display:flex; width:auto; min-width:82px; height:40px; padding:0 12px; align-items:center; justify-content:center; gap:6px; border-color:var(--accent); color:white; background:var(--accent); font-weight:750; }
      .icon.primary:hover { background:var(--accent-2); }
      .icon:disabled,.primary:disabled { cursor:not-allowed; opacity:.4; transform:none; }
      .bar { height:3px; background:var(--surface-2); }
      .bar span { display:block; height:100%; background:var(--accent); transition:width .25s ease; }
      .header { display:grid; grid-template-columns:auto 1fr auto; align-items:center; gap:8px; padding:10px; border-bottom:1px solid var(--line); }
      .brand { font-size:16px; font-weight:700; }
      .summary { color:var(--muted); font-size:12px; }
      .close { display:grid; width:34px; height:34px; place-items:center; border:1px solid var(--line); border-radius:10px; color:var(--muted); background:transparent; }
      .close:hover { color:var(--ink); background:var(--surface-2); }
      .list { max-height:min(440px,calc(100vh - 190px)); overflow:auto; padding:8px; overscroll-behavior:contain; }
      .row { display:grid; grid-template-columns:26px minmax(0,1fr) auto; column-gap:3px; align-items:center; min-height:43px; padding:5px 7px; border:1px solid transparent; border-radius:11px; }
      .row { cursor:pointer; }
      .row:hover { border-color:var(--line); background:var(--surface-2); }
      .row:focus-visible { outline:2px solid var(--accent); outline-offset:-2px; }
      .row.current { border-color:color-mix(in srgb,var(--accent) 36%,var(--line)); background:color-mix(in srgb,var(--accent) 9%,var(--surface)); }
      .status { display:grid; width:22px; height:22px; padding:0; place-items:center; border:0; border-radius:50%; color:var(--muted); background:var(--surface-2); font-size:11px; font-weight:750; }
      .status:hover { box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 18%,transparent); }
      .row.done .status { color:white; background:var(--done); }
      .row.skipped .status { color:white; background:var(--skip); }
      .game { min-width:0; overflow:hidden; font-weight:680; text-overflow:ellipsis; white-space:nowrap; }
      .trailing { display:flex; align-items:center; justify-content:flex-end; gap:3px; min-width:0; }
      .note { color:var(--muted); font-size:12px; font-weight:600; }
      .tab-note { display:inline-flex; align-items:center; gap:4px; padding:3px 6px; border-radius:999px; color:var(--accent); background:color-mix(in srgb,var(--accent) 10%,transparent); font-size:11px; font-weight:700; white-space:nowrap; }
      .tab-note::before { content:""; width:5px; height:5px; border-radius:50%; background:currentColor; }
      .undo { padding:4px 6px; border:0; border-radius:7px; color:var(--muted); background:transparent; font-size:12px; }
      .undo:hover { color:var(--ink); background:var(--surface); }
      .empty { padding:24px 10px; color:var(--muted); text-align:center; }
      .footer { display:grid; grid-template-columns:minmax(0,.76fr) minmax(0,1.24fr); align-items:center; gap:7px; padding:10px; border-top:1px solid var(--line); }
      .button { min-height:41px; padding:8px 12px; border:1px solid var(--line); border-radius:11px; color:var(--ink); background:var(--surface); font-weight:700; }
      .button:hover { background:var(--surface-2); }
      .button.primary { border-color:var(--accent); color:white; background:var(--accent); }
      .button.primary:hover { background:var(--accent-2); }
      .footer .skip-action,.footer .primary { display:flex; align-items:center; justify-content:center; gap:6px; }
      .footer .skip-action { color:var(--muted); }
      .footer .skip-action,.footer .primary { width:100%; height:44px; min-height:44px; }
      .mark-icon { display:block; width:16px; height:16px; flex:0 0 16px; overflow:visible; fill:none; stroke:currentColor; stroke-width:1.6; stroke-linecap:round; stroke-linejoin:round; shape-rendering:geometricPrecision; }
      .hint { padding:0 10px 10px; color:var(--muted); font-size:11px; text-align:center; }
      .celebration { padding:20px 18px 17px; text-align:center; }
      .celebration-mark { display:grid; width:62px; height:62px; margin:4px auto 13px; place-items:center; border-radius:20px; color:white; background:var(--accent); box-shadow:0 12px 30px color-mix(in srgb,var(--accent) 32%,transparent); font-size:28px; font-weight:750; animation:dp-pop .35s cubic-bezier(.2,.9,.25,1.3); }
      .celebration-mark .mark-icon { width:28px; height:28px; flex-basis:28px; }
      @keyframes dp-pop { from { opacity:0; transform:scale(.72) rotate(-8deg) } }
      .celebration h2 { margin:0; font-size:20px; letter-spacing:-.02em; }
      .celebration p { margin:6px auto 16px; max-width:260px; color:var(--muted); font-size:12px; }
      .celebration-stats { display:flex; justify-content:center; gap:7px; margin-bottom:16px; }
      .stat { padding:6px 9px; border-radius:9px; color:var(--muted); background:var(--surface-2); font-size:11px; font-weight:700; }
      .celebration-actions { display:grid; grid-template-columns:1fr auto; gap:7px; }
      #duplicate:empty { display:none; }
      .duplicate-card { width:min(350px,calc(100vw - 20px)); margin-bottom:8px; padding:11px; border:1px solid color-mix(in srgb,#aa651a 36%,#dedbd2); border-radius:14px; color:#171922; background:#fffefa; box-shadow:0 12px 34px rgba(16,18,28,.18); font:13px/1.4 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif; animation:dp-in .2s ease-out; }
      .duplicate-copy { margin-bottom:8px; font-weight:650; }
      .duplicate-actions { display:flex; justify-content:flex-end; gap:6px; }
      .duplicate-actions button { min-height:32px; padding:5px 9px; border:1px solid #dedbd2; border-radius:9px; color:#171922; background:#fffefa; font-weight:650; }
      .duplicate-actions .primary { border-color:#5b49d6; color:white; background:#5b49d6; }
      @media(prefers-color-scheme:dark){
        .shell { --ink:#f4f2ed; --muted:#a7a8b1; --surface:#191a1e; --surface-2:#25262c; --line:#3a3b42; --accent:#8b7cf0; --accent-2:#7566db; --done:#278b68; --skip:#b5732b; }
        .duplicate-card { color:#f4f2ed; background:#191a1e; border-color:#4b443a; }
        .duplicate-actions button { color:#f4f2ed; background:#25262c; border-color:#3a3b42; }
        .duplicate-actions .primary { color:white; background:#8b7cf0; border-color:#8b7cf0; }
      }
      @media(max-width:480px){ .shell{width:calc(100vw - 16px)} }
      @media(max-width:360px){ .compact{gap:6px;padding:7px}.copy{max-width:72px}.icon.skip-action{width:40px;min-width:40px;padding:0}.icon.primary{min-width:74px;padding:0 8px}.actions{gap:4px} }
      @media(prefers-reduced-motion:reduce){ *,*::before,*::after{animation-duration:.01ms!important;transition-duration:.01ms!important} }
    </style>
    <div id="duplicate"></div><div id="app"></div>`;
  const app = shadow.getElementById("app");
  const duplicateRoot = shadow.getElementById("duplicate");

  const escapeHtml = (value) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
  const playlist = () => core.activePlaylist(store);
  const games = () => playlist().games;
  const detected = () => core.findGameForUrl(games(), location.href);
  const identified = () => detected() || games().find((game) => core.findOpenGameTab(games(), [{ id:1, url:location.href }], game.id));
  const identifyFromStore = (candidateStore) => {
    const candidates = core.activePlaylist(candidateStore).games;
    return core.findGameForUrl(candidates, location.href)
      || candidates.find((game) => core.findOpenGameTab(candidates, [{ id:1, url:location.href }], game.id))
      || null;
  };
  const current = () => detected() || games().find((game) => game.id === store.lastOpenedGameId) || null;
  const status = (id) => core.getStatuses(store)[id] || "pending";
  const checkIcon = () => `<svg class="mark-icon check-mark" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2.75 8L6.5 11.75L13.25 4.25"></path></svg>`;
  const skipIcon = () => `<svg class="mark-icon skip-mark" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="8" r="6"></circle><path d="M3.75 12.25L12.25 3.75"></path></svg>`;
  const statusMarkup = (value) => value === "done" ? checkIcon() : value === "skipped" ? skipIcon() : "○";

  function tabLabel(gameId) {
    const value = tabState.games?.[gameId];
    if (value?.current || (!tabState.currentGameId && identified()?.id === gameId)) return "Current";
    if (value?.openCount > 0) return "Open";
    return "";
  }

  function trailingMarkup(game, value) {
    const label = tabLabel(game.id);
    const indicator = label ? `<span class="tab-note">${label}</span>` : "";
    const undo = value === "pending" ? "" : `<button class="undo" data-reset="${escapeHtml(game.id)}">Undo</button>`;
    return `${indicator}${undo}`;
  }

  async function persistStore() {
    localWrites += 1;
    try { store = await data.write(store); }
    finally { localWrites -= 1; }
    return store;
  }

  function positionHost() {
    const position = store?.ui?.position;
    if (!position || !Number.isFinite(position.x) || !Number.isFinite(position.y)) return;
    const rect = host.getBoundingClientRect();
    const x = Math.min(Math.max(6, position.x), Math.max(6, innerWidth - rect.width - 6));
    const y = Math.min(Math.max(6, position.y), Math.max(6, innerHeight - rect.height - 6));
    host.style.setProperty("left", `${x}px`, "important");
    host.style.setProperty("top", `${y}px`, "important");
    host.style.setProperty("right", "auto", "important");
    host.style.setProperty("bottom", "auto", "important");
  }

  function renderCompact() {
    const progress = core.deriveProgress(store);
    const game = current();
    const percent = progress.total ? progress.completed / progress.total * 100 : 100;
    app.innerHTML = `<div class="shell">
      <div class="compact">
        <button class="grip" data-drag aria-label="Move launcher" title="Move launcher">⋮⋮</button>
        <div class="copy"><div class="kicker">${progress.completed} / ${progress.total} today</div><div class="title">${escapeHtml(game?.name || "Choose a puzzle")}</div></div>
        <div class="actions">
          <button class="icon skip-action" data-action="skip" aria-label="Skip for today" title="Skip for today" ${game ? "" : "disabled"}>${skipIcon()}</button>
          <button class="icon primary" data-action="done" aria-label="Done and next" title="Done and next" ${game ? "" : "disabled"}>${checkIcon()}<span>Next</span></button>
          <button class="icon" data-action="expand" aria-label="Show today's queue" title="Show today's queue">☰</button>
        </div>
      </div><div class="bar"><span style="width:${Math.min(100, percent)}%"></span></div>
    </div>`;
  }

  function rows() {
    return games().filter((game) => game.enabled !== false).map((game) => {
      const value = status(game.id);
      const currentClass = tabLabel(game.id) === "Current" ? "current" : "";
      return `<div class="row ${value} ${currentClass}" data-open-row="${escapeHtml(game.id)}" role="button" tabindex="0" aria-label="Open ${escapeHtml(game.name)}">
        <button class="status" data-cycle="${escapeHtml(game.id)}" aria-label="Change ${escapeHtml(game.name)} status. Currently ${value}." title="Done → Skipped → Pending">${statusMarkup(value)}</button><span class="game">${escapeHtml(game.name)}</span><span class="trailing">${trailingMarkup(game, value)}</span>
      </div>`;
    }).join("");
  }

  function renderCelebration() {
    const progress = core.deriveProgress(store);
    app.innerHTML = `<div class="shell">
      <header class="header"><button class="grip" data-drag aria-label="Move launcher" title="Move launcher">⋮⋮</button><div><div class="brand">Daily Puzzles</div><div class="summary">Queue complete</div></div><button class="close" data-action="close-celebration" aria-label="Close celebration">×</button></header>
      <section class="celebration">
        <div class="celebration-mark">${checkIcon()}</div><h2>All set for today</h2><p>You made it through every puzzle in ${escapeHtml(playlist().name)}.</p>
        <div class="celebration-stats"><span class="stat">${progress.done} done</span>${progress.skipped ? `<span class="stat">${progress.skipped} skipped</span>` : ""}</div>
        <div class="celebration-actions"><button class="button primary" data-action="dismiss-celebration">Back to list</button><button class="button" data-action="close-celebration">Minimize</button></div>
      </section>
    </div>`;
  }

  function renderExpanded() {
    const progress = core.deriveProgress(store);
    app.innerHTML = `<div class="shell">
      <header class="header"><button class="grip" data-drag aria-label="Move launcher" title="Move launcher">⋮⋮</button>
        <div><div class="brand">Daily Puzzles</div><div class="summary">${progress.completed} of ${progress.total} finished${progress.skipped ? ` · ${progress.skipped} skipped` : ""}</div></div>
        <button class="close" data-action="collapse" aria-label="Minimize launcher">−</button></header>
      <div class="list">${rows() || `<div class="empty">Enable a puzzle from the extension toolbar.</div>`}</div>
      <footer class="footer"><button class="button skip-action" data-action="skip" aria-label="Skip for today" title="Skip for today" ${current() ? "" : "disabled"}>${skipIcon()}<span>Skip</span></button><button class="button primary" data-action="done" aria-label="Done and next" title="Done and next" ${current() ? "" : "disabled"}>${checkIcon()}<span>Done & next</span></button></footer>
      <div class="hint">Manage and reorder playlists from the toolbar icon</div>
    </div>`;
  }

  function render(preserveScroll = false) {
    if (!store) return;
    const currentScrollTop = app.querySelector(".list")?.scrollTop;
    const scrollTop = core.resolveScrollPosition(store.ui?.overlayScrollTop, currentScrollTop, preserveScroll);
    const progress = core.deriveProgress(store);
    const celebrating = store.ui?.showCelebration && store.ui?.celebrationDate === core.localDateKey() && progress.pending === 0;
    if (celebrating) renderCelebration(); else if (store.ui?.overlayExpanded) renderExpanded(); else renderCompact();
    const shell = app.querySelector(".shell");
    if (hasRendered && shell) shell.style.animation = "none";
    const list = app.querySelector(".list");
    if (list) list.scrollTop = scrollTop;
    hasRendered = true;
    queueMicrotask(positionHost);
  }

  async function patch(mutator, preserveScroll = false) {
    const next = JSON.parse(JSON.stringify(store));
    mutator(next);
    store = core.normalizeStore(next);
    render(preserveScroll);
    await persistStore();
  }

  function refreshStatus(gameId) {
    const progress = core.deriveProgress(store);
    const row = [...app.querySelectorAll("[data-open-row]")].find((item) => item.dataset.openRow === gameId);
    const game = games().find((item) => item.id === gameId);
    const value = status(gameId);
    if (row && game) {
      row.classList.remove("pending", "done", "skipped");
      row.classList.add(value);
      const circle = row.querySelector("[data-cycle]");
      circle.innerHTML = statusMarkup(value);
      circle.setAttribute("aria-label", `Change ${game.name} status. Currently ${value}.`);
      const trailing = row.querySelector(".trailing");
      trailing.innerHTML = trailingMarkup(game, value);
    }
    const summary = app.querySelector(".summary");
    if (summary) summary.textContent = `${progress.completed} of ${progress.total} finished${progress.skipped ? ` · ${progress.skipped} skipped` : ""}`;
    const kicker = app.querySelector(".kicker");
    if (kicker) kicker.textContent = `${progress.completed} / ${progress.total} today`;
    const bar = app.querySelector(".bar span");
    if (bar) bar.style.width = `${Math.min(100, progress.total ? progress.completed / progress.total * 100 : 100)}%`;
  }

  function refreshTabIndicators() {
    for (const row of app.querySelectorAll("[data-open-row]")) {
      const game = games().find((item) => item.id === row.dataset.openRow);
      if (!game) continue;
      const value = status(game.id);
      row.classList.toggle("current", tabLabel(game.id) === "Current");
      const trailing = row.querySelector(".trailing");
      if (trailing) trailing.innerHTML = trailingMarkup(game, value);
    }
  }

  function showDuplicateNotice(gameId, puzzleName) {
    duplicateGameId = gameId;
    duplicateRoot.innerHTML = `<div class="duplicate-card" role="status"><div class="duplicate-copy">${escapeHtml(puzzleName)} is already open in another tab.</div><div class="duplicate-actions"><button data-duplicate="keep">Keep both</button><button class="primary" data-duplicate="use">Use existing tab</button></div></div>`;
  }

  function closeDuplicateNotice() {
    duplicateGameId = null;
    duplicateRoot.innerHTML = "";
  }

  async function requestOpen(game, navigationIntent = "browse") {
    const result = await chrome.runtime.sendMessage({ type:"open-game", gameId:game.id, navigationIntent });
    if (result?.action === "error") throw new Error(result.message || "The puzzle could not be opened");
    return result;
  }

  function rememberOverlayScroll() {
    const list = app.querySelector(".list");
    if (!list) return false;
    const scrollTop = Math.max(0, Math.round(list.scrollTop));
    if (store.ui.overlayScrollTop === scrollTop) return false;
    store.ui.overlayScrollTop = scrollTop;
    return true;
  }

  async function openGame(game) {
    if (!game) return;
    rememberOverlayScroll();
    store.lastOpenedGameId = game.id;
    await persistStore();
    await requestOpen(game);
  }

  async function finish(value) {
    if (saving || !current()) return;
    saving = true;
    try {
      const game = current();
      rememberOverlayScroll();
      store = core.setGameStatus(store, game.id, value);
      store.lastOpenedGameId = game.id;
      refreshStatus(game.id);
      await persistStore();
      const nextGame = core.nextPendingGame(store, game.id);
      if (!nextGame) {
        store.ui.overlayExpanded = true;
        store.ui.showCelebration = true;
        store.ui.celebrationDate = core.localDateKey();
        await persistStore();
        render();
        return;
      }
      store.lastOpenedGameId = nextGame.id;
      await persistStore();
      await requestOpen(nextGame, "finished-handoff");
    } finally {
      saving = false;
    }
  }

  app.addEventListener("click", async (event) => {
    const cycle = event.target.closest("[data-cycle]");
    if (cycle) {
      const id = cycle.dataset.cycle;
      store = core.setGameStatus(store, id, core.nextGameStatus(status(id)));
      refreshStatus(id);
      await persistStore();
      return;
    }
    const button = event.target.closest("button");
    if (button?.disabled) return;
    if (button?.dataset.action === "expand") { await patch((next) => { next.ui.overlayExpanded = true; }); return; }
    if (button?.dataset.action === "collapse") { await patch((next) => { next.ui.overlayExpanded = false; }); return; }
    if (button?.dataset.action === "dismiss-celebration") { await patch((next) => { next.ui.showCelebration = false; next.ui.overlayExpanded = true; }); return; }
    if (button?.dataset.action === "close-celebration") { await patch((next) => { next.ui.showCelebration = false; next.ui.overlayExpanded = false; }); return; }
    if (button?.dataset.action === "done") { await finish("done"); return; }
    if (button?.dataset.action === "skip") { await finish("skipped"); return; }
    if (button?.dataset.reset) {
      const id = button.dataset.reset;
      store = core.setGameStatus(store, id, "pending");
      refreshStatus(id);
      await persistStore();
      return;
    }
    const row = event.target.closest("[data-open-row]");
    if (row) await openGame(games().find((game) => game.id === row.dataset.openRow));
  });

  app.addEventListener("keydown", (event) => {
    const row = event.target.closest("[data-open-row]");
    if (row && event.target === row && ["Enter", " "].includes(event.key)) {
      event.preventDefault();
      openGame(games().find((game) => game.id === row.dataset.openRow));
    }
  });

  duplicateRoot.addEventListener("click", async (event) => {
    const action = event.target.closest("[data-duplicate]")?.dataset.duplicate;
    if (!action || !duplicateGameId) return;
    if (action === "keep") {
      await chrome.runtime.sendMessage({ type:"dismiss-duplicate", gameId:duplicateGameId });
      closeDuplicateNotice();
      return;
    }
    if (action === "use") {
      const result = await chrome.runtime.sendMessage({ type:"use-existing-tab", gameId:duplicateGameId });
      if (result?.action === "error" || result?.action === "missing") closeDuplicateNotice();
    }
  });

  app.addEventListener("scroll", (event) => {
    if (!event.target.matches?.(".list") || !rememberOverlayScroll()) return;
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = setTimeout(() => persistStore().catch((error) => console.error("Could not save launcher scroll position", error)), 120);
  }, true);

  let drag = null;
  app.addEventListener("pointerdown", (event) => {
    const handle = event.target.closest("[data-drag]");
    if (!handle) return;
    const rect = host.getBoundingClientRect();
    drag = { pointerId:event.pointerId, dx:event.clientX - rect.left, dy:event.clientY - rect.top };
    handle.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  app.addEventListener("pointermove", (event) => {
    if (!drag || drag.pointerId !== event.pointerId) return;
    const rect = host.getBoundingClientRect();
    const x = Math.min(Math.max(6, event.clientX - drag.dx), Math.max(6, innerWidth - rect.width - 6));
    const y = Math.min(Math.max(6, event.clientY - drag.dy), Math.max(6, innerHeight - rect.height - 6));
    host.style.setProperty("left", `${x}px`, "important"); host.style.setProperty("top", `${y}px`, "important");
    host.style.setProperty("right", "auto", "important"); host.style.setProperty("bottom", "auto", "important");
  });
  app.addEventListener("pointerup", async (event) => {
    if (!drag || drag.pointerId !== event.pointerId) return;
    drag = null;
    const rect = host.getBoundingClientRect();
    store.ui.position = { x:Math.round(rect.left), y:Math.round(rect.top) };
    await persistStore();
  });

  addEventListener("resize", () => requestAnimationFrame(positionHost));
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "launcher-present") { sendResponse({ present:true }); return false; }
    if (message?.type === "identify-puzzle-tab") {
      if (store) { sendResponse({ gameId:identified()?.id || null }); return false; }
      data.read().then((next) => sendResponse({ gameId:identifyFromStore(next)?.id || null })).catch(() => sendResponse({ gameId:null }));
      return true;
    }
    if (message?.type === "matches-game") {
      const matches = Boolean(store && core.findOpenGameTab(games(), [{ id:1, url:location.href }], message.gameId));
      sendResponse({ matches });
      return false;
    }
    if (message?.type === "tab-state") {
      tabState = message.state || tabState;
      refreshTabIndicators();
      return false;
    }
    return false;
  });

  async function registerCurrentTab(allowDuplicateNotice) {
    const game = identified();
    if (!game) return;
    const result = await chrome.runtime.sendMessage({ type:"register-puzzle-tab", gameId:game.id, suppressDuplicate:!allowDuplicateNotice });
    if (result?.state) { tabState = result.state; refreshTabIndicators(); }
    if (allowDuplicateNotice && result?.duplicate) showDuplicateNotice(game.id, result.duplicate.puzzleName || game.name);
  }

  data.subscribe((next) => {
    if (localWrites) { store = next; return; }
    if (JSON.stringify(next) === JSON.stringify(store)) return;
    store = next;
    render(true);
    registerCurrentTab(false).catch(() => {});
  });
  data.read().then(async (next) => {
    store = next;
    const game = detected();
    if (game && store.lastOpenedGameId !== game.id) {
      store.lastOpenedGameId = game.id;
      await persistStore();
    }
    render();
    await registerCurrentTab(true);
  }).catch((error) => { console.error("Daily Puzzle Launcher failed to start", error); host.remove(); });
})();
