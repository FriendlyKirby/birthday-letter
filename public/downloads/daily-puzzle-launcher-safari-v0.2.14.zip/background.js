importScripts("core.js", "storage.js");

const core = globalThis.DailyPuzzlesCore;
const data = globalThis.DailyPuzzlesStorage;
const SESSION_KEY = "daily-puzzle-launcher:tab-state";
const EXPECTED_TTL = 30_000;
let sessionQueue = Promise.resolve();
let discoveryComplete = false;

const STATIC_OVERLAY_HOSTS = new Set([
  "betweenle.com", "wordgy.com", "bonedle.rito.lol", "loldle.net", "pokedle.net", "smashdle.net",
  "bandle.app", "www.minutecryptic.com", "contexto.me", "conexo.ws", "letroso.com", "expresso.ac"
]);

function hasStaticOverlay(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (STATIC_OVERLAY_HOSTS.has(url.hostname)) return true;
    return url.hostname === "www.nytimes.com" && (
      url.pathname.startsWith("/games/") ||
      url.pathname.startsWith("/crosswords/game/mini") ||
      url.pathname.startsWith("/puzzles/letter-boxed") ||
      url.pathname.startsWith("/puzzles/spelling-bee")
    );
  } catch {
    return false;
  }
}

function originPattern(rawUrl) {
  const url = new URL(rawUrl);
  return `${url.protocol}//${url.hostname}/*`;
}

function scriptId(pattern) {
  let hash = 2166136261;
  for (const character of pattern) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return `custom-site-${(hash >>> 0).toString(36)}`;
}

async function restoreCustomContentScripts() {
  if (!chrome.scripting?.getRegisteredContentScripts || !chrome.scripting?.registerContentScripts) return;
  const store = await data.read();
  const origins = [...new Set(
    store.playlists
      .flatMap((playlist) => playlist.games || [])
      .filter((game) => game?.url && !hasStaticOverlay(game.url))
      .map((game) => originPattern(game.url))
  )];
  if (!origins.length) return;

  const registered = await chrome.scripting.getRegisteredContentScripts();
  const existingIds = new Set(registered.map((script) => script.id));
  const additions = [];
  for (const origin of origins) {
    if (existingIds.has(scriptId(origin))) continue;
    const granted = await chrome.permissions.contains({ origins:[origin] });
    if (!granted) continue;
    additions.push({
      id:scriptId(origin),
      matches:[origin],
      js:["core.js", "storage.js", "content.js"],
      runAt:"document_end",
      persistAcrossSessions:true
    });
  }
  if (additions.length) await chrome.scripting.registerContentScripts(additions);
}

function blankSession() {
  return { tabs:{}, expected:{} };
}

function normalizeSession(value) {
  const next = value && typeof value === "object" ? value : blankSession();
  next.tabs = next.tabs && typeof next.tabs === "object" ? next.tabs : {};
  next.expected = next.expected && typeof next.expected === "object" ? next.expected : {};
  const now = Date.now();
  for (const [tabId, expected] of Object.entries(next.expected)) {
    if (!expected || Number(expected.expiresAt) < now) delete next.expected[tabId];
  }
  return next;
}

async function readSession() {
  const result = await chrome.storage.session.get(SESSION_KEY);
  return normalizeSession(result[SESSION_KEY]);
}

function updateSession(mutator) {
  sessionQueue = sessionQueue.then(async () => {
    const state = await readSession();
    const result = await mutator(state) || state;
    await chrome.storage.session.set({ [SESSION_KEY]:result });
    return result;
  });
  return sessionQueue;
}

function numericTabId(value) {
  const id = Number(value);
  return Number.isInteger(id) ? id : null;
}

function chooseMostRecent(entries, excludedTabId = null) {
  return entries
    .filter(({ tabId }) => tabId !== excludedTabId)
    .sort((a, b) => b.lastActiveAt - a.lastActiveAt || b.tabId - a.tabId)[0] || null;
}

function tabEntries(state, gameId = null) {
  return Object.entries(state.tabs).map(([key, value]) => ({ tabId:Number(key), ...value }))
    .filter((entry) => Number.isInteger(entry.tabId) && (!gameId || entry.gameId === gameId));
}

function publicTabState(state, contextTabId = null) {
  const games = {};
  for (const entry of tabEntries(state)) {
    const current = entry.tabId === contextTabId;
    const summary = games[entry.gameId] ||= { openCount:0, current:false, openElsewhere:false, mostRecentTabId:null, mostRecentAt:-1 };
    summary.openCount += 1;
    summary.current ||= current;
    if (!current) summary.openElsewhere = true;
    if (entry.lastActiveAt >= summary.mostRecentAt) {
      summary.mostRecentAt = entry.lastActiveAt;
      summary.mostRecentTabId = entry.tabId;
    }
  }
  for (const value of Object.values(games)) delete value.mostRecentAt;
  return {
    anyPuzzleOpen:Object.keys(state.tabs).length > 0,
    currentTabId:contextTabId,
    currentGameId:state.tabs[String(contextTabId)]?.gameId || null,
    games
  };
}

async function broadcast(state) {
  const tasks = [chrome.runtime.sendMessage({ type:"tab-state-changed" }).catch(() => {})];
  for (const entry of tabEntries(state)) {
    tasks.push(chrome.tabs.sendMessage(entry.tabId, { type:"tab-state", state:publicTabState(state, entry.tabId) }).catch(() => {}));
  }
  await Promise.all(tasks);
}

async function setExpectedNavigation(tabId, gameId, suppressAny = false) {
  return updateSession((state) => {
    state.expected[String(tabId)] = { gameId, suppressAny, expiresAt:Date.now() + EXPECTED_TTL };
  });
}

async function clearExpectedNavigation(tabId) {
  return updateSession((state) => { delete state.expected[String(tabId)]; });
}

async function identifyTab(tab, allowInjection = true) {
  if (!tab?.id) return null;
  const ask = async () => {
    const response = await chrome.tabs.sendMessage(tab.id, { type:"identify-puzzle-tab" });
    return typeof response?.gameId === "string" ? response.gameId : null;
  };
  try {
    const gameId = await ask();
    if (gameId || !allowInjection) return gameId;
  } catch {
    if (!allowInjection) return null;
  }
  try {
    await setExpectedNavigation(tab.id, null, true);
    await chrome.scripting.executeScript({ target:{ tabId:tab.id }, files:["core.js", "storage.js", "content.js"] });
    const gameId = await ask();
    if (!gameId) await clearExpectedNavigation(tab.id);
    return gameId;
  } catch {
    await clearExpectedNavigation(tab.id);
    return null;
  }
}

async function discoverTabs(store) {
  const games = core.activePlaylist(store).games;
  const gameIds = new Set(games.map((game) => game.id));
  const browserTabs = await chrome.tabs.query({});
  const aliveIds = new Set(browserTabs.map((tab) => String(tab.id)));
  const identified = await Promise.all(browserTabs.map(async (tab) => ({ tab, gameId:await identifyTab(tab) })));
  const state = await updateSession((next) => {
    for (const key of Object.keys(next.tabs)) if (!aliveIds.has(key)) delete next.tabs[key];
    for (const { tab, gameId } of identified) {
      if (!tab.id) continue;
      const key = String(tab.id);
      if (!gameId || !gameIds.has(gameId)) { delete next.tabs[key]; continue; }
      const previous = next.tabs[key];
      next.tabs[key] = {
        gameId,
        windowId:tab.windowId,
        lastActiveAt:previous?.lastActiveAt || (tab.active ? Date.now() : 0),
        keepBothGameId:previous?.gameId === gameId ? previous.keepBothGameId || null : null
      };
    }
  });
  return state;
}

async function ensureTabRegistry(store) {
  const current = await readSession();
  if (discoveryComplete || Object.keys(current.tabs).length) {
    discoveryComplete = true;
    return current;
  }
  const discovered = await discoverTabs(store);
  discoveryComplete = true;
  return discovered;
}

async function focusTab(tabId) {
  const tab = await chrome.tabs.update(tabId, { active:true });
  if (Number.isInteger(tab?.windowId)) await chrome.windows.update(tab.windowId, { focused:true });
  return tab;
}

async function registerPuzzleTab(message, sender) {
  const tab = sender.tab;
  if (!tab?.id || typeof message.gameId !== "string") return { registered:false };
  const store = await data.read();
  const game = core.activePlaylist(store).games.find((item) => item.id === message.gameId);
  if (!game) return { registered:false };
  let duplicate = null;
  const state = await updateSession((next) => {
    const key = String(tab.id);
    const previous = next.tabs[key];
    const expected = next.expected[key];
    const extensionInitiated = Boolean(message.suppressDuplicate || (expected && (expected.suppressAny || expected.gameId === game.id)));
    delete next.expected[key];
    const existing = chooseMostRecent(tabEntries(next, game.id), tab.id);
    const kept = previous?.gameId === game.id && previous.keepBothGameId === game.id;
    next.tabs[key] = {
      gameId:game.id,
      windowId:tab.windowId,
      lastActiveAt:tab.active ? Date.now() : previous?.lastActiveAt || 0,
      keepBothGameId:previous?.gameId === game.id ? previous.keepBothGameId || null : null
    };
    if (!extensionInitiated && existing && !kept) duplicate = { puzzleName:game.name, existingTabId:existing.tabId };
  });
  await broadcast(state);
  return { registered:true, duplicate, state:publicTabState(state, tab.id) };
}

async function dismissDuplicate(message, sender) {
  if (!sender.tab?.id || typeof message.gameId !== "string") return { dismissed:false };
  const state = await updateSession((next) => {
    const entry = next.tabs[String(sender.tab.id)];
    if (entry?.gameId === message.gameId) entry.keepBothGameId = message.gameId;
  });
  await broadcast(state);
  return { dismissed:true };
}

async function useExistingTab(message, sender) {
  const duplicateTabId = sender.tab?.id;
  if (!duplicateTabId || typeof message.gameId !== "string") return { action:"missing" };
  const state = await readSession();
  const existing = chooseMostRecent(tabEntries(state, message.gameId), duplicateTabId);
  if (!existing) return { action:"missing" };
  await focusTab(existing.tabId);
  await chrome.tabs.remove(duplicateTabId);
  return { action:"focused-and-closed", tabId:existing.tabId, closedTabId:duplicateTabId };
}

async function getTabState(message, sender) {
  const store = await data.read();
  const contextTabId = sender.tab?.id ?? numericTabId(message.sourceTabId);
  const discovered = await ensureTabRegistry(store);
  const state = contextTabId && discovered.tabs[String(contextTabId)]
    ? await updateSession((next) => { next.tabs[String(contextTabId)].lastActiveAt = Date.now(); })
    : discovered;
  return publicTabState(state, contextTabId);
}

async function openGame(message, sender) {
  const store = await data.read();
  const games = core.activePlaylist(store).games;
  const target = games.find((game) => game.id === message.gameId);
  if (!target) return { action:"missing" };
  const sourceTabId = sender.tab?.id ?? numericTabId(message.sourceTabId);
  let state = await ensureTabRegistry(store);
  const existing = chooseMostRecent(tabEntries(state, target.id));
  if (existing) {
    const tab = await focusTab(existing.tabId);
    let closedSourceTabId = null;
    const shouldCloseFinishedSource = message.navigationIntent === "finished-handoff"
      && sourceTabId !== existing.tabId
      && Boolean(state.tabs[String(sourceTabId)]);
    if (shouldCloseFinishedSource) {
      const sourceTab = await chrome.tabs.get(sourceTabId).catch(() => null);
      if (sourceTab && !sourceTab.pinned) {
        try {
          await chrome.tabs.remove(sourceTabId);
          closedSourceTabId = sourceTabId;
        } catch {}
      }
    }
    state = await updateSession((next) => {
      if (closedSourceTabId) {
        delete next.tabs[String(closedSourceTabId)];
        delete next.expected[String(closedSourceTabId)];
      }
      if (next.tabs[String(existing.tabId)]) next.tabs[String(existing.tabId)].lastActiveAt = Date.now();
    });
    await broadcast(state);
    return {
      action:existing.tabId === sourceTabId ? "already-open" : closedSourceTabId ? "focused-and-closed-source" : "focused",
      tabId:existing.tabId,
      windowId:tab?.windowId,
      ...(closedSourceTabId ? { closedSourceTabId } : {})
    };
  }

  const sourceIsPuzzle = sourceTabId && state.tabs[String(sourceTabId)];
  const fallbackPuzzle = chooseMostRecent(tabEntries(state));
  const reuseTabId = sourceIsPuzzle ? sourceTabId : fallbackPuzzle?.tabId || null;
  if (reuseTabId) {
    state = await updateSession(current => {
      current.expected[String(reuseTabId)] = {
        gameId:target.id,
        suppressAny:false,
        expiresAt:Date.now() + EXPECTED_TTL
      };
      delete current.tabs[String(reuseTabId)];
      return current;
    });
    await broadcast(state);
    const tab = await chrome.tabs.update(reuseTabId, { url:target.url, active:true });
    if (Number.isInteger(tab?.windowId)) await chrome.windows.update(tab.windowId, { focused:true });
    return { action:"navigated", tabId:reuseTabId };
  }

  const created = await chrome.tabs.create({ url:"about:blank", active:false });
  await setExpectedNavigation(created.id, target.id);
  const tab = await chrome.tabs.update(created.id, { url:target.url, active:true });
  if (Number.isInteger(tab?.windowId)) await chrome.windows.update(tab.windowId, { focused:true });
  return { action:"created", tabId:created.id };
}

async function recordActivation(tabId, windowId) {
  const state = await updateSession((next) => {
    const entry = next.tabs[String(tabId)];
    if (entry) { entry.lastActiveAt = Date.now(); entry.windowId = windowId; }
  });
  await broadcast(state);
}

async function removeTab(tabId) {
  const state = await updateSession((next) => {
    delete next.tabs[String(tabId)];
    delete next.expected[String(tabId)];
  });
  await broadcast(state);
}

async function refreshUpdatedTab(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return;
  const gameId = await identifyTab(tab, false);
  const state = await updateSession((next) => {
    const key = String(tabId);
    if (!gameId) delete next.tabs[key];
    else if (next.tabs[key]) next.tabs[key].gameId = gameId;
  });
  await broadcast(state);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handlers = {
    "register-puzzle-tab":registerPuzzleTab,
    "dismiss-duplicate":dismissDuplicate,
    "use-existing-tab":useExistingTab,
    "get-tab-state":getTabState,
    "open-game":openGame
  };
  const handler = handlers[message?.type];
  if (!handler) return false;
  handler(message, sender).then(sendResponse).catch((error) => sendResponse({ action:"error", message:error?.message || String(error) }));
  return true;
});


chrome.runtime.onInstalled.addListener(() => {
  restoreCustomContentScripts().catch((error) => console.error("Could not restore custom puzzle overlays", error));
});

chrome.tabs.onActivated.addListener(({ tabId, windowId }) => recordActivation(tabId, windowId).catch(() => {}));
chrome.tabs.onRemoved.addListener((tabId) => removeTab(tabId).catch(() => {}));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => changeInfo.status === "complete" ? refreshUpdatedTab(tabId).catch(() => {}) : undefined);
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  chrome.tabs.query({ active:true, windowId }).then(([tab]) => { if (tab?.id) return recordActivation(tab.id, windowId); }).catch(() => {});
});
