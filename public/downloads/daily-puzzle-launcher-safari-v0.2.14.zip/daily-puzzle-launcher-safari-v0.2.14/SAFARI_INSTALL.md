# Daily Puzzle Launcher — Safari build

This folder contains Safari-ready WebExtension resources for Daily Puzzle Launcher v0.2.14.

## Compatibility

- Safari 16.4 or later is required for the APIs this extension uses (`storage.session` and dynamic content-script registration).
- The same extension resources can be packaged for macOS, iOS, and iPadOS.
- The source still uses the `chrome.*` WebExtension namespace intentionally; Safari supports both `chrome.*` and `browser.*` namespaces.

## Quick local install on a Mac

1. Open **Safari > Settings**.
2. Enable Safari's web-developer features (in Advanced settings, enable the option to show features for web developers if needed).
3. Open the **Developer** settings pane and enable **Allow Unsigned Extensions**.
4. Choose **Add Temporary Extension…**.
5. Select the `extension` folder in this package (the folder containing `manifest.json`).
6. Enable **Daily Puzzle Launcher** and grant website access when Safari asks.

Temporary/unsigned extensions are intended for development and local use. Safari may require them to be enabled again after restarting or changing developer settings.

## iPhone / iPad, TestFlight, or normal distribution

Safari Web Extensions are distributed inside a containing app. Apple currently offers two routes:

### App Store Connect packager

Upload the contents of the `extension` folder to the **Safari Web Extension Packager** in App Store Connect. This can be done from a browser without a Mac, but distribution requires Apple Developer Program access. You can then send a TestFlight build or submit it to the App Store.

### Xcode / command line on a Mac

With current Xcode installed, run:

```sh
xcrun safari-web-extension-packager --copy-resources "/full/path/to/daily-puzzle-launcher-safari-v0.2.14/extension"
```

That generates the containing Safari app/Xcode project. Build it, enable its extension in Safari, and grant the requested website permissions.

## Safari-specific change in this build

Safari dynamically registered content scripts persist across browser restarts but can be lost when the extension itself is updated. This build restores the custom-site content scripts in `background.js` after install/update, so user-added puzzle websites keep their in-page launcher overlay after an update.

## Notes

- Built-in puzzle sites are declared statically in `manifest.json`.
- User-added puzzle sites still request permission only for the site being added.
- No native Safari-only code is required for the extension's current feature set.
