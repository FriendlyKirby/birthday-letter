# Daily Puzzle Launcher — Chrome Web Store submission guide

Use `daily-puzzle-launcher-chrome-brave-v0.2.14.zip` as the extension package. Copy the text below exactly unless a field contains a placeholder for your eventual public website.

## Store listing

### Product details

**Title from package:** Daily Puzzle Launcher

**Summary from package:** Move through your daily puzzles in one tab with a clean queue, skip controls, and custom playlists.

**Description:**

```text
Daily Puzzle Launcher turns daily puzzle websites into one focused routine.

Open the toolbar popup to see today's queue, current progress, and the earliest puzzle that is neither finished nor skipped. On supported puzzle pages, a compact in-page control lets you mark the current puzzle done, skip it for today, or open the full queue.

Features:
• An 18-puzzle default playlist that you can customize
• Multiple playlists with add, remove, enable, disable, and drag-to-reorder controls
• Manual Done and Skip status that resets for each local calendar day
• Current and Open indicators for puzzle tabs
• Existing-tab reuse to avoid duplicate puzzle tabs and preserve unfinished games
• A compact, expandable, draggable in-page launcher
• Playlist import from JSON files or reviewed manual paste
• Playlist export to a file or copied JSON
• Local-only progress and settings with no account, analytics, advertising, or remote code

To provide Current/Open indicators and avoid unnecessary duplicates, the extension checks the URLs of configured and open puzzle tabs locally. This information never leaves the browser. The extension does not inspect puzzle answers, page text, form entries, cookies, or account information.

Built-in puzzle sites receive only the access needed to display the launcher. If you add a puzzle on another domain, Chrome asks for access to that specific site at that time. The extension does not request access to every website during installation.

Puzzle completion is intentionally manual so the extension works consistently across unrelated puzzle websites without reading their game state.
```

**Category:** Workflow & Planning

**Language:** English

### Graphic assets

- **Store icon:** `assets/store-icon-128x128.png`
- **Screenshots, in this order:**
  1. `assets/screenshot-1-daily-queue-1280x800.png`
  2. `assets/screenshot-2-in-page-overlay-1280x800.png`
  3. `assets/screenshot-3-playlist-manager-1280x800.png`
- **Small promo tile:** `assets/small-promo-tile-440x280.png`
- **Marquee promo tile:** `assets/marquee-promo-tile-1400x560.png`
- **Global promo video:** Leave blank unless you later make a YouTube demonstration.

All supplied promotional images are opaque RGB PNGs. The store icon is a 128×128 PNG.

### Additional fields

- **Official URL:** None, unless you own and have verified a website in Google Search Console.
- **Homepage URL:** Leave blank for now. After publishing the included `website/` folder, use its public HTTPS URL.
- **Support URL:** Leave blank or use the hosted homepage URL. Chrome's built-in Support hub can be enabled instead.
- **Mature content:** Off.
- **Item support visibility:** On is recommended so users can use the store's Support hub.

## Privacy

### Single purpose

```text
Organize and navigate a user-defined queue of daily puzzle websites, with local progress tracking and in-page controls for moving through that queue.
```

### Permission justifications

**storage justification:**

```text
Stores playlists, puzzle order, enabled state, daily Done/Skipped status, and interface preferences locally so progress remains consistent between the toolbar popup and the in-page launcher. This data is not synced or sent to the developer.
```

**scripting justification:**

```text
Registers the packaged in-page launcher on a custom puzzle domain only after the user adds that domain and grants optional site access. The extension executes only JavaScript included in its package and does not download or execute remote code.
```

**Host permission justification:**

```text
Host access is limited to the built-in puzzle URLs listed in the manifest so the extension can display its visible launcher and identify which configured puzzle is open. Access for a user-added domain is optional and requested only after the user explicitly adds that site. Host access is not used to read puzzle answers, page text, form data, cookies, or account information, and no data is transmitted to the developer or a third party.
```

### Remote code

Select **No, I am not using remote code**. No additional justification is needed.

### Data usage

- Select **Web history** only. Chrome defines domains and URLs that the extension processes—even locally—as web browsing activity.
- Do not select Personally identifiable information, Health information, Financial and payment information, Authentication information, Personal communications, Location, User activity, or Website content.
- Check all three certifications:
  - I do not sell or transfer user data to third parties, outside approved use cases.
  - I do not use or transfer user data for purposes unrelated to the item's single purpose.
  - I do not use or transfer user data to determine creditworthiness or for lending purposes.

### Privacy policy URL

This field requires a public HTTPS page. The ready-to-host policy is `website/privacy-policy.html`. After hosting the included website folder, paste the public URL here, for example:

```text
https://YOUR-USERNAME.github.io/daily-puzzle-launcher/privacy-policy.html
```

Do not submit the extension until this URL opens publicly without a login.

## Distribution

- **Payments:** Free of charge.
- **Visibility:** Public.
- **Geographic distribution:** All regions. Do not add exclusions unless you specifically want regional restrictions.

## Test instructions

Leave username and password blank.

**Additional instructions:**

```text
No login or test account is required. Pin the extension, then open https://www.nytimes.com/games/wordle/index.html to see the compact launcher. Expand it to view the queue and status controls. Open the toolbar popup to test Today and Playlists, including status cycling and drag reordering. Continue, Done & next, Skip, and puzzle rows reuse existing puzzle tabs. Adding a custom domain requests optional access only for that site. Completion is manual; answers are never inspected.
```

## Final submission order

1. Host `website/` and confirm the privacy-policy URL is public.
2. Upload `daily-puzzle-launcher-chrome-brave-v0.2.14.zip` on the Package tab.
3. Complete Store listing using the copy and images above.
4. Complete Privacy using the exact disclosures above.
5. Set Distribution to Free, Public, and All regions.
6. Add the reviewer instructions and leave credentials blank.
7. Save every tab and resolve any red required-field warnings.
8. Select **Submit for review**. Choose deferred publishing only if you want to manually release it after approval.

## Policy basis

- Chrome requires at least one 1280×800 screenshot and explains the listing fields: <https://developer.chrome.com/docs/webstore/cws-dashboard-listing/>
- Chrome requires minimum permissions and a justification for each: <https://developer.chrome.com/docs/webstore/cws-dashboard-privacy/>
- Chrome treats processed domains and URLs as browsing activity, even when handled locally: <https://developer.chrome.com/docs/webstore/program-policies/user-data-faq>
- Chrome requires an accurate public privacy policy when user data is handled: <https://developer.chrome.com/docs/webstore/program-policies/privacy>
- Chrome distribution options are documented here: <https://developer.chrome.com/docs/webstore/cws-dashboard-distribution>
